<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminAppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <h2>Orders</h2>
    <hr>


    <section class='container'>
        <div class="row d-flexx justify-content-center mt-4">
            <div class="col-xl-4 col-lg-4 col-md-5 mb-4">
                <div class="eachSortSect card card-body p-2">
                    <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">ORDER DETAILS</p>

                    <div class="d-flex justify-content-between">
                        <p>Order Number:</p>
                        <p><?php echo e(strtoupper($order->order_number)); ?> </p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Order Status:</p>
                        <p>
                            <?php if($order->status == 'pending'): ?>
                            <span class="bg-gray text-info" style="font-size: 13px">Pending</span>
                            <?php elseif($order->status == 'delivered'): ?>
                            <span class="bg-gray text-success" style="font-size: 13px">Delivered</span>
                            <?php elseif($order->status == 'cancelled'): ?>
                            <span class="bg-gray text-danger" style="font-size: 13px"><?php echo e($order->status); ?></span>
                            <?php elseif($order->status == 'processing'): ?>
                            <span class="bg-gray text-warning" style="font-size: 13px"><?php echo e($order->status); ?></span>
                            <?php elseif($order->status == 'shipped'): ?>
                            <span class="bg-gray text-info" style="font-size: 13px"><?php echo e($order->status); ?></span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Payment Method:</p>
                        <p>
                            <?php if($order->payment_method == 'pay_now'): ?>
                            Instant Payment
                            <?php else: ?>
                            Pay on delivery
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Created On:</p>
                        <p><?php echo e(date('d M, Y', strtotime($order->created_at))); ?> </p>
                    </div>


                    <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">SHIPPING ADDRESS</p>
                    <div class="">
                        <p class="mb-0">Address:</p>
                        <p><?php echo e($order->address); ?> </p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>State:</p>
                        <p><?php echo e($order->state); ?> </p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Country:</p>
                        <p><?php echo e($order->country); ?> </p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Phone:</p>
                        <p><?php echo e($order->phone); ?> </p>
                    </div>

                </div>

                <div class="eachSortSect card card-body p-2 mt-4">
                    <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">ORDER STATUS</p>
                    

                    <div class="form-group">
                        <label for="">Change order status</label>
                        <select onchange="changeOrderStatus(<?php echo e($order->id); ?>)" name="status"  id="ordStatus" class="form-control custom-select">
                            <option <?php if($order->status == 'pending'): ?> selected <?php endif; ?> value="pending">Pending</option>
                            <option <?php if($order->status == 'processing'): ?> selected <?php endif; ?> value="processing">Processing</option>
                            <option <?php if($order->status == 'shipped'): ?> selected <?php endif; ?> value="shipped">Shipped</option>
                            <option <?php if($order->status == 'delivered'): ?> selected <?php endif; ?> value="delivered">Delivered</option>
                            <option <?php if($order->status == 'cancelled'): ?> selected <?php endif; ?> value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8 col-md-7 mb-4">
                
                <div class="eachSortSect card card-body p-2">
                    <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">PRODUCTS</p>

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row orderDetails mb-4">
                        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col-3 forcartImgDiv">
                            <img src="<?php echo e($pro->image); ?>" class="cartimg" alt="/">
                        </div>
                        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-9">
                            <div class="dz-head">
                                <div class="d-flex justify-content-between">
                                    <h6 class="title mb-0"><?php echo e($pro->name); ?></h6>
                                </div>
                            </div>
                            <div class="dz-body mt-3">
                                <p class="mb-1 text-muted">
                                    <span>category:</span>
                                    <?php echo e(ucwords(str_replace('-', ' ', $pro->category))); ?>

                                </p>
                                <p class="mb-1 text-muted">
                                    <span>Price:</span> <?php echo e(number_format($pro->price)); ?>,
                                    <span>Qty:</span> <?php echo e($pro->quantity); ?>,
                                </p>
                                <p class="mb-1 text-muted">
                                    <span>Total Price:</span>
                                    <?php echo e($curr); ?><?php echo e(number_format($pro->price * $pro->quantity)); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>

                    <div class="d-flex justify-content-end mb-2">
                        <div class="text-muted mr-4">Sub Total</div>
                        <div class="price"><?php echo e($curr); ?><?php echo e(number_format($order->total_amount)); ?></div>
                    </div>
                    <div class="d-flex justify-content-end mb-2">
                        <div class="text-muted mr-4">Shipping Fee</div>
                        <div class="price"><?php echo e($curr); ?><?php echo e(number_format($order->shipping_fee)); ?></div>
                    </div>
                    <div class="d-flex justify-content-end mb-2">
                        <div class="text-muted mr-4">Coupon</div>
                        <div class="price">Null</div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end mb-4">
                        <div class="text-muted mr-4">Total</div>
                        <div class="price"><strong><?php echo e($curr); ?><?php echo e(number_format($order->total_amount + $order->shipping_fee)); ?></strong></div>
                    </div>
                </div>
            </div>

        </div>
    </section>




     <!-- The Modal -->
    <div class="modal fade" id="orderStatusMo">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">

                <form action="<?php echo e(route('updateOrderStatus')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <!-- Modal body -->
                    <div class="modal-body text-center">
                        <p class="mt-3">Are you sure you want to <span id="theAction"></span> this order</p>
                        <input type="hidden" id="ordStaInputAct" name="staAction">
                        <input type="hidden" id="ordStaInputID" name="staID">

                        <div class="mt-4 mb-3">
                            <button class="btn btn-success btn-sm mr-4">Yes</button>
                            <button class="btn btn-danger btn-sm" data-dismiss="modal">No</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>



    <script>
        function changeOrderStatus(orderID) {
            var htmlAction = document.getElementById('ordStatus').value;
            var toSubmit = document.getElementById('ordStatus').value;

            if(htmlAction == 'Pending'){
                htmlAction = 'Pend';
            } else if(htmlAction == 'Processing'){
                htmlAction = 'Process';
            }

            document.getElementById('theAction').innerHTML = htmlAction;
            document.getElementById('ordStaInputAct').value = toSubmit;
            document.getElementById('ordStaInputID').value = orderID;
            $('#orderStatusMo').modal();
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\ecommerce\resources\views/admins/orders/details.blade.php ENDPATH**/ ?>