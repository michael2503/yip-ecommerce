<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activepage' => 'order']); ?>

    <?php $__env->startSection('title', "Orders"); ?>

    <?php $__env->startSection('description', "Welcome to Yip Online Ecommerce"); ?>
    <?php $__env->startSection('ogTitle', 'Welcome to Yip Online Ecommerce'); ?>
    <?php $__env->startSection('ogImage', asset('assets/images/yip-online.png')); ?>
    <?php $__env->startSection('ogUrl', Request::url()); ?>


    <div class='productwrapper'>
        <section class='container'>
            <div class="row d-flexx justify-content-center">
                <div class="col-xl-8 col-lg-8 mb-4">
                    
                    <div class="eachSortSect">
                        <div class="d-flex justify-content-between bg-light pt-2 pl-3 pr-3 pb-1 mb-4">
                            <div class="widget-title">
                                <h6 class="title m-b30">All Order <span class="">(<?php echo e($orders->total()); ?>)</span></h6>
                            </div>
                        </div>

                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row orderDetails mb-4">
                            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col-3 forcartImgDiv">
                                <img src="<?php echo e(json_decode($order->product_info)[0]->image); ?>" class="cartimg" alt="/">
                            </div>
                            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-9">
                                <div class="dz-head">
                                    <a href="<?php echo e(route('orderDetails', [$order->id, $order->order_number])); ?>">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="title mb-0">ORDER - <?php echo e(strtoupper($order->order_number)); ?></h6>
                                            <h6 class="title mb-0"><?php echo e($curr); ?><?php echo e(number_format($order->total_amount)); ?></h6>
                                        </div>
                                    </a>
                                </div>
                                <div class="dz-body mt-3">
                                    <p class="mb-1 text-muted"><span>Created On: </span> <?php echo e(date('d M, Y', strtotime($order->created_at))); ?></p>
                                    <p class="mb-1 text-muted">
                                        <span>Payment Method:</span>
                                        <?php if($order->payment_method == 'pay_now'): ?>
                                        Instant Payment
                                        <?php else: ?>
                                        Pay on delivery
                                        <?php endif; ?>
                                    </p>
                                    <p class="mb-1 text-muted">
                                        <span>Status:</span>

                                        <?php if($order->status == 'pending'): ?>
                                        <span class="bg-gray text-info" style="font-size: 13px">Pending</span>
                                        <?php elseif($order->status == 'delivered'): ?>
                                        <span class="bg-gray text-success" style="font-size: 13px">Delivered</span>
                                        <?php elseif($order->status == 'cancelled'): ?>
                                        <span class="bg-gray text-danger" style="font-size: 13px"><?php echo e($order->status); ?></span>
                                        <?php elseif($order->status == 'processing'): ?>
                                        <span class="bg-gray text-warning" style="font-size: 13px"><?php echo e($order->status); ?></span>
                                        <?php elseif($order->status == 'shipped'): ?>
                                        <span class="bg-gray text-info" style="font-size: 13px"><?php echo e($order->status); ?></span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </section>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php /**PATH C:\Laravel\ecommerce\resources\views/users/orders.blade.php ENDPATH**/ ?>