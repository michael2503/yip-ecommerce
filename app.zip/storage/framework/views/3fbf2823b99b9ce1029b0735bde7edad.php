<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Yip Online Ecommerce System">
    <meta name="robots" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Mobile Specific -->


    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
    <meta name="keywords" content="Yip Online Ecommerce System" />
    <meta property="og:title" content="<?php echo $__env->yieldContent('ogTitle'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Yip Online Ecommerce System">
    <meta property="og:locale" content="en_US">
    <meta property="og:url" content="<?php echo $__env->yieldContent('ogUrl'); ?>" />

    <meta prefix="og: http://ogp.me/ns#" property="og:title" content="<?php echo $__env->yieldContent('ogTitle'); ?>">
    <meta prefix="og: http://ogp.me/ns#" property="og:image" content="<?php echo $__env->yieldContent('ogImage'); ?>">
    <meta prefix="og: http://ogp.me/ns#" property="og:description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta prefix="og: http://ogp.me/ns#" property="og:url" content="<?php echo $__env->yieldContent('ogUrl'); ?>">

    <meta name="twitter:card" content="Yip Online Ecommerce System">
    <meta name="twitter:site" content="Yip Online Ecommerce System">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('ogTitle'); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('ogImage'); ?>">
    <link rel="canonical" href="<?php echo $__env->yieldContent('ogUrl'); ?>">
    <link rel="alternate" href="<?php echo $__env->yieldContent('ogUrl'); ?>">

    <link rel="shortcut icon" href="<?php echo $__env->yieldContent('ogImage'); ?>" type="image/x-icon" />

        <!-- Fonts -->

        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick-theme.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.min.css')); ?>" />

        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">


    </head>
    <body>
        <?php $countCart = 0; ?>

        <?php if(session('cart')): ?>
        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $countCart += $details['quantity']; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <header>
            <div class="topheader">
                <div class="container container1230">
                    <div class="row">
                        <div class="col-xl-8 col-lg-7 col-md-10 col-sm-9 remove575">
                            <div class="d-flex justify-content-start">
                                <p class='mb-0'>
                                    <span class='phoneTitle'>Call Us: </span>
                                    <span class="phone ml-2">+(084) 123 - 456 88</span>
                                </p>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-2 col-sm-3">
                            <div class="socialside d-flex justify-content-end">
                                <a class='ml-2' href="#" tabIndex={5}>
                                    <img src=""<?php echo e(asset('assets/images/linkedin.png')); ?> />
                                </a>
                                <a class='ml-2' href="#" tabIndex={5}>
                                    <img src="<?php echo e(asset('assets/images/twitter.png')); ?>" />
                                </a>
                                <a class='ml-2' href="#" tabIndex={5}>
                                    <img src="<?php echo e(asset('assets/images/facebook.png')); ?>" />
                                </a>
                                <a class='ml-2' href="#" tabIndex={5}>
                                    <img src="<?php echo e(asset('assets/images/instagram.png')); ?>" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="bottomheader bottomheaderBorder">
                <div class="container container1230">
                    <div class="d-flex justify-content-between">
                        <div class="themenus">
                            <div class="d-flex justify-content-between">
                                <div class="link mr-5">
                                    <a href="<?php echo e(route('homePage')); ?>">
                                        <img src="<?php echo e(asset('assets/images/yip-online.png')); ?>" class='logo'/>
                                    </a>
                                </div>
                                <div class="link mt-2 mr-3">
                                    <a href="<?php echo e(route('homePage')); ?>" <?php if($attributes['activepage'] == 'home'): ?> class="active" <?php endif; ?>>
                                        Home
                                    </a>
                                </div>
                                <div class="link mt-2 mr-3">
                                    <a href="<?php echo e(route('products')); ?>" <?php if($attributes['activepage'] == 'product'): ?> class="active" <?php endif; ?>>
                                        Product
                                    </a>
                                </div>
                                <?php if(Auth::user()): ?>
                                <div class="link mt-2 mr-3">
                                    <a href="<?php echo e(route('getOrder')); ?>" <?php if($attributes['activepage'] == 'order'): ?> class="active" <?php endif; ?>>
                                        Orders
                                    </a>
                                </div>
                                <div class="link mt-2 mr-3">
                                    <a href="<?php echo e(route('getWishList')); ?>" <?php if($attributes['activepage'] == 'wishlist'): ?> class="active" <?php endif; ?>>
                                        Wishlist
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="rightside remove800">
                            <div class="d-flex justify-content-end">

                                <div class="link mr-4">
                                    <a href="<?php echo e(route('shoppingCart')); ?>" class='login navcartlink'>
                                        <span class="fa fa-shopping-cart navcart"></span>
                                        <span class="count ajaxCountOne"><?php echo e($countCart); ?></span>
                                    </a>
                                </div>

                                <?php if(Auth::user()): ?>
                                <div class="createaccbtn mt-2">
                                    <a href="javascript:void(0)" onclick="event.preventDefault(); document.getElementById('userLogout').submit();">
                                        Logout
                                    </a>
                                </div>
                                <?php else: ?>
                                <div class="link mt-3 mr-4">
                                    <a href="<?php echo e(route('login')); ?>" class='login'>
                                        <span>Login</span>
                                    </a>
                                </div>
                                <div class="createaccbtn mt-2">
                                    <a href="<?php echo e(route('register')); ?>">
                                        Register
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mobileview">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <a href="<?php echo e(route('homePage')); ?>">
                                        <img src="<?php echo e(asset('assets/images/yip-online.png')); ?>" class='logo'/>
                                    </a>
                                </div>

                                <div class="d-flex">
                                    <div class="link mr-4">
                                        <a href="<?php echo e(route('shoppingCart')); ?>" class='login navcartlink'>
                                            <span class="fa fa-shopping-cart navcart mobile"></span>
                                            <span class="count ajaxCountTwo mobile"><?php echo e($countCart); ?></span>
                                        </a>
                                    </div>

                                    <input class="side-menu" type="checkbox" id="side-menu"/>
                                    <label class="hamb" for="side-menu"><span class="hamb-line"></span></label>

                                    <nav class="nav">
                                        <ul class="menu">
                                            <li>
                                                <a href="<?php echo e(route('homePage')); ?>">
                                                    Home
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('products')); ?>">
                                                    Product
                                                </a>
                                            </li>
                                            <?php if(Auth::user()): ?>
                                            <li>
                                                <a href="<?php echo e(route('dashboard')); ?>">
                                                    Dashboard
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('getOrder')); ?>">
                                                    Orders
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('getWishList')); ?>">
                                                    Wishlist
                                                </a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)" onclick="event.preventDefault(); document.getElementById('userLogout').submit();">
                                                    Logout
                                                </a>
                                            </li>
                                            <?php else: ?>
                                            <li>
                                                <a href="<?php echo e(route('login')); ?>">
                                                    Login
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('register')); ?>">
                                                    register
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </nav>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </header>
         <form id="userLogout" action="<?php echo e(route('logout')); ?>" method="post">
            <?php echo csrf_field(); ?>
        </form>


        <?php echo e($slot); ?>



        <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Laravel\ecommerce\resources\views/layouts/guest.blade.php ENDPATH**/ ?>