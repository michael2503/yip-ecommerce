<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminAppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


        <h2>Product Category</h2>
        <hr>




        <div class="row">
            <div class="col-xl-6">
                <div class="card card-body p-2">
                    <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">ADD CATEGORY</p>

                    <form action="<?php echo e(route('admincategory.post')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                        <div class="form-group mt-4">
                            <label for="">category <span class="text-danger">*</span></label>
                            <input type="text" class="form-control proName" name="category" value="<?php echo e(old('category')); ?>">
                            <p class="text-danger mb-0"><small><?php echo e($errors->first('category')); ?></small></p>
                        </div>

                        <div class="mt-4 text-center mb-3">
                            <button class="btn btn-primary btn-sm">Submit Category</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="card card-body p-2">
                    <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">ALL CATEGORIES</p>

                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between">
                        <p><?php echo e($cat->category); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </div>


            </div>
        </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\ecommerce\resources\views/admins/products/category.blade.php ENDPATH**/ ?>