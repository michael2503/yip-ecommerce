<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activepage' => 'carts']); ?>

    <?php $__env->startSection('title', "Shopping Cart"); ?>

    <?php $__env->startSection('description', "Welcome to Yip Online Ecommerce"); ?>
    <?php $__env->startSection('ogTitle', 'Welcome to Yip Online Ecommerce'); ?>
    <?php $__env->startSection('ogImage', asset('assets/images/yip-online.png')); ?>
    <?php $__env->startSection('ogUrl', Request::url()); ?>


    <div class='productwrapper'>

        <section class='container'>

            <div class="row d-flex justify-content-center">
                <div class="col-xl-6 col-lg-7 col-md-8 col-sm-10"><?php if (isset($component)) { $__componentOriginal1811699cff5444317c92659701378323 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1811699cff5444317c92659701378323 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1811699cff5444317c92659701378323)): ?>
<?php $attributes = $__attributesOriginal1811699cff5444317c92659701378323; ?>
<?php unset($__attributesOriginal1811699cff5444317c92659701378323); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1811699cff5444317c92659701378323)): ?>
<?php $component = $__componentOriginal1811699cff5444317c92659701378323; ?>
<?php unset($__componentOriginal1811699cff5444317c92659701378323); ?>
<?php endif; ?></div>
            </div>



            <div class="row">
                <div class="col-xl-8 col-lg-8 mb-4">
                    
                    <div class="eachSortSect">
                        <div class="d-flex justify-content-between bg-light pt-2 pl-3 pr-3 pb-1 mb-4">
                            <div class="widget-title">
                                <?php $countCart = 0; ?>

                                <?php if(session('cart')): ?>
                                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $countCart += $details['quantity']; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                <h6 class="title m-b30">Cart <span class="">(<?php echo e($countCart); ?>)</span></h6>
                            </div>
                            <a href="<?php echo e(route('clearAllCart')); ?>" class="text-danger"><small><small><strong>CLEAR CART</strong></small></small></a>
                        </div>

                        <?php $total = 0 ?>
                        <?php if(session('cart')): ?>
                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $total += $details['price'] * $details['quantity'] ?>

                        <div class="row mb-4">
                            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col-3 forcartImgDiv">
                                <img src="<?php echo e($details['image']); ?>" class="cartimg" alt="/">
                            </div>
                            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-9">
                                <div class="dz-head" data-id="<?php echo e($id); ?>">
                                    <h6 class="title mb-0"><?php echo e($details['name']); ?></h6>
                                </div>
                                <div class="dz-body">
                                    <div class="btn-quantity style-1 mt-3" style="width: 120px">
                                        <div class="input-group mb-3 input-group-sm" data-id="<?php echo e($id); ?>" style="">
                                            <div class="input-group-prepend" onclick="updateCart('minus', <?php echo e($id); ?>)">
                                                <span class="input-group-text fa fa-minus mobilePlus" style="height: 31px"></span>
                                            </div>
                                            <input style="width: 50px; text-align: center; border-right: none" id="cartQty_<?php echo e($id); ?>" value="<?php echo e($details['quantity']); ?>" readonly type="text" class="form-control">
                                            <div class="input-group-prepend" onclick="updateCart('plus', <?php echo e($id); ?>)">
                                                <span class="input-group-text fa fa-plus mobilePlus" style="height: 31px"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-between">
                                        <h5 class="price mb-0"><?php echo e($curr); ?><?php echo e(number_format($details['price'] * $details['quantity'])); ?></h5>
                                        <a href="javascript:void(0);" class="remove-from-cart"><i class="fa fa-trash text-danger"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="order-detail">
                            <div class="d-flex justify-content-between">
                                <div>Sub Total</div>
                                <div class="price"><strong><?php echo e($curr); ?><?php echo e(number_format($total)); ?></strong></div>
                            </div>
                        </div>

                        <?php else: ?>

                        <h6 class="text-center mt-3">No Product</h6>

                        <?php endif; ?>

                        <div class="links-box mt-5 mb-3">
                            <a class="btn btn-primary bg-dark border-dark" href="<?php echo e(route('products')); ?>">
                                <span class="btn-txt">Continue Shopping</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4">
                    <div class="eachSortSect">
                        <div class="d-flex justify-content-between bg-light pt-2 pl-3 pr-3 pb-1 mb-4">
                            <div class="widget-title">
                                <h6 class="title m-b30">Summary</h6>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between mb-4">
                            <div class="text-muted">Sub Total</div>
                            <div class="price"><?php echo e($curr); ?><?php echo e(number_format($total)); ?></div>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <div class="text-muted">Shipping Fee</div>
                            <div class="price">Null</div>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <div class="text-muted">Coupon</div>
                            <div class="price">Null</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <div class="text-muted">Total</div>
                            <div class="price"><strong><?php echo e($curr); ?><?php echo e(number_format($total)); ?></strong></div>
                        </div>

                         <?php if(session('cart')): ?>
                            <div class="links-box mt-5">
                                <a class="btn btn-primary btn-block" href="<?php echo e(route('checkoutView')); ?>">
                                    Checkout
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </section>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<script>
    function updateCart(param, cartID) {
        var cartQty = document.querySelector('#cartQty_'+ cartID).value;

        var qty = parseInt(cartQty) - 1;
        if(param == 'plus'){
            qty = parseInt(cartQty) + 1;
        }
        $.ajax({
            url: '<?php echo e(route('updateProductCart')); ?>',
            method: "patch",
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                id: cartID,
                quantity: qty
            },
            success: function (response) {
                window.location.reload();
            }
        });
    }
</script>
<?php /**PATH C:\Laravel\ecommerce\resources\views/guest/shopping-carts.blade.php ENDPATH**/ ?>