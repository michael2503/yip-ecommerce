<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activepage' => 'product']); ?>

    <?php $__env->startSection('title', "Products"); ?>

    <style>
        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
        }
        .slider {
            height: 5px;
            position: relative;
            background: #ddd;
            border-radius: 5px;
        }
        .slider .progress {
            height: 100%;
            left: 25%;
            right: 25%;
            position: absolute;
            border-radius: 5px;
            background: #7da640;
        }
        .range-input {
            position: relative;
        }
        .range-input input {
            position: absolute;
            width: 100%;
            height: 5px;
            top: -5px;
            background: none;
            pointer-events: none;
            -webkit-appearance: none;
            -moz-appearance: none;
        }
        input[type="range"]::-webkit-slider-thumb {
            height: 17px;
            width: 17px;
            border-radius: 50%;
            background: #7da640;
            pointer-events: auto;
            -webkit-appearance: none;
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.05);
        }
        input[type="range"]::-moz-range-thumb {
            height: 17px;
            width: 17px;
            border: none;
            border-radius: 50%;
            background: #7da640;
            pointer-events: auto;
            -moz-appearance: none;
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.05);
        }
    </style>

    <?php $__env->startSection('description', "Welcome to Yip Online Ecommerce"); ?>
    <?php $__env->startSection('ogTitle', 'Welcome to Yip Online Ecommerce'); ?>
    <?php $__env->startSection('ogImage', asset('assets/images/yip-online.png')); ?>
    <?php $__env->startSection('ogUrl', Request::url()); ?>


    <div class='productwrapper'>

        <section class='container'>

            <div class="row d-flex justify-content-center">
                <div class="col-xl-6 col-lg-7 col-md-8 col-sm-10"><?php if (isset($component)) { $__componentOriginal1811699cff5444317c92659701378323 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1811699cff5444317c92659701378323 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1811699cff5444317c92659701378323)): ?>
<?php $attributes = $__attributesOriginal1811699cff5444317c92659701378323; ?>
<?php unset($__attributesOriginal1811699cff5444317c92659701378323); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1811699cff5444317c92659701378323)): ?>
<?php $component = $__componentOriginal1811699cff5444317c92659701378323; ?>
<?php unset($__componentOriginal1811699cff5444317c92659701378323); ?>
<?php endif; ?></div>
            </div>

            <div class="row">
                <div class="col-xl-9">

                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-4 col-sm-6 mb-4">
                                <div class="product-grid">
                                    <div class="product-image">
                                        <a href="<?php echo e(route('productDetails', [$pro->id, $pro->slug])); ?>" class="image">
                                            <img class="pic-1" src="<?php echo e($pro->image); ?>">
                                        </a>
                                        <ul class="product-links text-center">
                                            <li>
                                                <a <?php if($pro->isWish): ?> style="background: #000066" <?php endif; ?> href="<?php echo e(route('addProToWishList', $pro->id)); ?>" data-tip="Add to Wishlist">
                                                    <i class="fa fa-heart" <?php if($pro->isWish): ?> style="color: #fff" <?php endif; ?>></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="product-content">
                                        <h3 class="title mb-3"><a href="<?php echo e(route('productDetails', [$pro->id, $pro->slug])); ?>"><?php echo e($pro->name); ?></a></h3>
                                        <div class="price mb-3 d-flex justify-content-between">
                                            <div><?php echo e($curr.number_format($pro->sales_price)); ?></div>
                                            <?php if($pro->old_price): ?>
                                            <div class="oldprice"><del><?php echo e($curr.number_format($pro->old_price)); ?></del></div>
                                            <?php endif; ?>
                                        </div>

                                        
                                        <div class="isNotLoading isNotLoading<?php echo e($pro->id); ?>">
                                            <a href="<?php echo e(route('addProductTocart', $pro->id)); ?>"  class="add-cart"><i class="fas fa-cart-plus"></i>Add to cart</a>
                                            
                                        </div>
                                        <div class="isLoading isLoading<?php echo e($pro->id); ?>">
                                            <a href="javascript:()" class="add-cart "><i class="fa fa-spinner fa-spin"></i>Adding to cart...</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>

                    <?php if($products->total() > 0): ?>
                    <div class="d-flex justify-content-center">
                        <?php echo e($products->links()); ?>

                    </div>
                    <?php endif; ?>

                </div>

                <div class="col-xl-3">
                    <div class="card card-body filter p-2">
                        <div class="eachFilter mb-4">
                            <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">SEARCH</p>

                            <div class="input-group mb-3">
                                <input type="text" class="form-control searchInput" placeholder="Search">
                                <div class="input-group-append">
                                    <button class="btn btn-success" type="button" onclick="submitSearch()">Go</button>
                                </div>
                            </div>
                        </div>

                        <div class="eachFilter">
                            <p class="bg-secondary text-white pt-2 pr-3 pb-2 pl-3">CATEGORIES</p>
                            <?php $catcount = 1; ?>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="custom-control custom-checkbox mb-3" onclick="sortByCat('<?php echo e($cat->slug); ?>')">
                                <input type="checkbox" class="custom-control-input" <?php if($theTypeValue == $cat->slug): ?> checked <?php endif; ?> value="<?php echo e($cat->slug); ?>" id="<?php echo e($cat->slug); ?><?php echo e($catcount); ?>">
                                <label class="custom-control-label" for="<?php echo e($cat->slug); ?><?php echo e($catcount); ?>"><?php echo e($cat->category); ?></label>
                            </div>
                            <?php $catcount += 1; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </div>

                        <div class="eachFilter mt-4 mb-3">
                           <div class="d-flex justify-content-between bg-secondary text-white pt-2 pr-3 pb-2 pl-3">
                                <p class="mb-0">PRICE RANGE</p>
                                <p class="apply mb-0" onclick="submitPrice()" style="cursor: pointer">APPLY</p>
                            </div>

                            <div class="wrapper">
                                <div class="price-input d-flex justify-content-between mb-3 mt-3">
                                    <div class="field">
                                        <input type="number" class="input-min" value="0" style="height: 35px; width: 50px; text-align: center; padding: 0px">
                                    </div>
                                    <div style="text-align: center">
                                        <span>-</span>
                                    </div>
                                    <div class="field">
                                        <input type="number" class="input-max" value="<?php echo e($maxPrice); ?>" style="height: 35px; width: 50px; padding: 0px; text-align: center">
                                    </div>
                                </div>
                                <div class="slider">
                                    <div class="progress"></div>
                                </div>
                                <div class="range-input">
                                    <input type="range" class="range-min" min="0" max="<?php echo e($maxPrice); ?>" value="0" step="100">
                                    <input type="range" class="range-max" min="0" max="<?php echo e($maxPrice); ?>" value="<?php echo e($maxPrice); ?>" step="100">
                                </div>
                            </div>
                        </div>




                    </div>
                </div>
            </div>

        </section>

    </div>

    <script>
        function sortByCat(cat) {
            window.location = "<?php echo e(url('')); ?>/products/filter?type=category&value=" + cat;
        }
        function submitSearch(cat) {
            var input = document.querySelector('.searchInput').value;
            window.location = "<?php echo e(url('')); ?>/products/filter?type=search&value=" + input;
        }
        function submitPrice() {
            var from = document.querySelector('.input-min').value;
            var to = document.querySelector('.input-max').value;

            window.location = "<?php echo e(url('')); ?>/products/filter?type=price&value=" + from + "-" + to;
        }


    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<script>
    const rangeInput = document.querySelectorAll(".range-input input"),
    priceInput = document.querySelectorAll(".price-input input"),
    range = document.querySelector(".slider .progress");
    let priceGap = 1000;

    priceInput.forEach((input) => {
        input.addEventListener("input", (e) => {
            let minPrice = parseInt(priceInput[0].value),
            maxPrice = parseInt(priceInput[1].value);

            if (maxPrice - minPrice >= priceGap && maxPrice <= rangeInput[1].max) {
                if (e.target.className === "input-min") {
                    rangeInput[0].value = minPrice;
                    range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
                } else {
                    rangeInput[1].value = maxPrice;
                    range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
                }
            }
        });
    });
    rangeInput.forEach((input) => {
        input.addEventListener("input", (e) => {
            let minVal = parseInt(rangeInput[0].value),
            maxVal = parseInt(rangeInput[1].value);
            if (maxVal - minVal < priceGap) {
                if (e.target.className === "range-min") {
                    rangeInput[0].value = maxVal - priceGap;
                } else {
                    rangeInput[1].value = minVal + priceGap;
                }
            } else {
                priceInput[0].value = minVal;
                priceInput[1].value = maxVal;
                range.style.left = (minVal / rangeInput[0].max) * 100 + "%";
                range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
            }
        });
    });
</script>
<?php /**PATH C:\Laravel\ecommerce\resources\views/guest/products.blade.php ENDPATH**/ ?>