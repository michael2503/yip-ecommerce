<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activepage' => 'home']); ?>

    <?php $__env->startSection('title', "Home Page"); ?>

    <?php $__env->startSection('description', "Welcome to Yip Online Ecommerce"); ?>
    <?php $__env->startSection('ogTitle', 'Welcome to Yip Online Ecommerce'); ?>
    <?php $__env->startSection('ogImage', asset('assets/images/yip-online.png')); ?>
    <?php $__env->startSection('ogUrl', Request::url()); ?>


    <div class='wrapper'>

        <section class='homebanner'>
            <div class='container-fluid'>
                <div class='row no-gutters'>
                    <div class='col-xl-6 col-lg-6 col-md-6'>
                        <div class='bannerwriteup'>
                            <p class='smalltitle'>WELCOME TO YIPONLINE</p>
                            <h1>Promoting Ecommerce System.</h1>
                            <p class='description'>Creating a sustainable financial institution that empowers individuals and businesses to reach their full potentials, while delivering excellent returns to our investors.</p>
                            <a href="<?php echo e(route('homePage')); ?>" class='btn btn-primary'>
                                <span class='pr-2'>Get Started</span>
                                <svg width="12" class='inlineBlock' height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_138_587)">
                                        <path d="M0 5.50002H10.2857M10.2857 5.50002L6 1.21252M10.2857 5.50002L6 9.78752" stroke="white" stroke-width="1.5"/>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_138_587">
                                            <rect width="12" height="10.29" fill="white" transform="translate(0 0.35498)"/>
                                        </clipPath>
                                    </defs>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class='col-xl-6 col-lg-6 col-md-6'>
                        <div class='imgwrap'>
                            <img src="<?php echo e(asset('assets/images/home-banner.png')); ?>" />
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php /**PATH C:\Laravel\ecommerce\resources\views/guest/home.blade.php ENDPATH**/ ?>