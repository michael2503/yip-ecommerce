<?php if(Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\Laravel\ecommerce\resources\views/components/success.blade.php ENDPATH**/ ?>