<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminAppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


        <h5>Orders</h5>
        <hr>

        <div class="card card-body">
            <div class="table-responsive-sm">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Order Number</th>
                            <th>User</th>
                            <th>Total Amount</th>
                            <th>Status</th>
                            <th>Created On</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(strtoupper($item->order_number)); ?></td>
                            <td><?php echo e(ucwords($item->user->name)); ?></td>
                            <td><?php echo e($curr.number_format($item->total_amount)); ?></td>

                            <td>
                                <?php if($item->status == 'pending'): ?>
                                <span class="bg-gray text-info" style="font-size: 13px">Pending</span>
                                <?php elseif($item->status == 'delivered'): ?>
                                <span class="bg-gray text-success" style="font-size: 13px">Delivered</span>
                                <?php elseif($item->status == 'cancelled'): ?>
                                <span class="bg-gray text-danger" style="font-size: 13px"><?php echo e($item->status); ?></span>
                                <?php elseif($item->status == 'processing'): ?>
                                <span class="bg-gray text-warning" style="font-size: 13px"><?php echo e($item->status); ?></span>
                                <?php elseif($item->status == 'shipped'): ?>
                                <span class="bg-gray text-info" style="font-size: 13px"><?php echo e($item->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(date('d M, Y', strtotime($item->created_at))); ?></td>
                            <td>
                                <a href="<?php echo e(route('adminOrderDetails', [$item->id, $item->order_number])); ?>" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></a>
                                <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center" colspan="6">No Order</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-center">
                <?php echo e($orders->links()); ?>

            </div>
        </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\ecommerce\resources\views/admins/orders/lists.blade.php ENDPATH**/ ?>