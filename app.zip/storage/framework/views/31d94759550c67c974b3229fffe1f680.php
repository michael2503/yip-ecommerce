<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activepage' => 'wishlist']); ?>

    <?php $__env->startSection('title', "Wishlist"); ?>

    <?php $__env->startSection('description', "Welcome to Yip Online Ecommerce"); ?>
    <?php $__env->startSection('ogTitle', 'Welcome to Yip Online Ecommerce'); ?>
    <?php $__env->startSection('ogImage', asset('assets/images/yip-online.png')); ?>
    <?php $__env->startSection('ogUrl', Request::url()); ?>


    <div class='productwrapper'>

        <section class='container'>

            <div class="row d-flex justify-content-center">
                <div class="col-xl-6 col-lg-7 col-md-8 col-sm-10"><?php if (isset($component)) { $__componentOriginal1811699cff5444317c92659701378323 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1811699cff5444317c92659701378323 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1811699cff5444317c92659701378323)): ?>
<?php $attributes = $__attributesOriginal1811699cff5444317c92659701378323; ?>
<?php unset($__attributesOriginal1811699cff5444317c92659701378323); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1811699cff5444317c92659701378323)): ?>
<?php $component = $__componentOriginal1811699cff5444317c92659701378323; ?>
<?php unset($__componentOriginal1811699cff5444317c92659701378323); ?>
<?php endif; ?></div>
            </div>

            <div class="row">
                <div class="col-xl-9">

                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-4 col-sm-6 mb-4">
                                <div class="product-grid">
                                    <div class="product-image">
                                        <a href="<?php echo e(route('productDetails', [$pro->product->id, $pro->product->slug])); ?>" class="image">
                                            <img class="pic-1" src="<?php echo e($pro->product->image); ?>">
                                        </a>
                                        <ul class="product-links text-center">
                                            <li><a style="background: #000066" href="<?php echo e(route('addProToWishList', $pro->id)); ?>" data-tip="Add to Wishlist"><i class="fa fa-heart" style="color: #fff"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="product-content">
                                        <h3 class="title mb-3"><a href="<?php echo e(route('productDetails', [$pro->product->id, $pro->product->slug])); ?>"><?php echo e($pro->product->name); ?></a></h3>
                                        <div class="price mb-3 d-flex justify-content-between">
                                            <div><?php echo e($curr.number_format($pro->product->sales_price)); ?></div>
                                            <?php if($pro->product->old_price): ?>
                                            <div class="oldprice"><del><?php echo e($curr.number_format($pro->product->old_price)); ?></del></div>
                                            <?php endif; ?>
                                        </div>

                                        
                                        <div class="isNotLoading isNotLoading<?php echo e($pro->product->id); ?>">
                                            <a href="<?php echo e(route('addProductTocart', $pro->product->id)); ?>"  class="add-cart"><i class="fas fa-cart-plus"></i>Add to cart</a>
                                            
                                        </div>
                                        <div class="isLoading isLoading<?php echo e($pro->product->id); ?>">
                                            <a href="javascript:()" class="add-cart "><i class="fa fa-spinner fa-spin"></i>Adding to cart...</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-center">
                        <?php echo e($wishlists->links()); ?>

                    </div>

                </div>

                <div class="col-xl-3"></div>
            </div>

        </section>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\ecommerce\resources\views/users/wishlist.blade.php ENDPATH**/ ?>