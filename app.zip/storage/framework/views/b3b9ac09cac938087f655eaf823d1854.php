<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminAppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


        <h2>Dashboard</h2>
        <hr>


        <div class="row">
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                <div class="card card-body p-2 rounded mb-4">
                    <div class="d-flex justify-content-between">
                        <div class="icon">
                            <h2 class="bg-success p-3 mt-1 rounded-circle text-white"><i class="fa fa-users"></i></h2>
                        </div>
                        <div>
                            <p class="mb-0 mt-2 text-muted">Total Users</p>
                            <h4 class="mb-0 mt-2 text-right"><?php echo e($allUsers); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                <div class="card card-body p-2 rounded mb-4">
                    <div class="d-flex justify-content-between">
                        <div class="icon">
                            <h2 class="bg-success p-3 mt-1 rounded-circle text-white"><i class="fa fa-shopping-cart"></i></h2>
                        </div>
                        <div>
                            <p class="mb-0 mt-2 text-muted">All Orders</p>
                            <h4 class="mb-0 mt-2 text-right"><?php echo e($allOrders); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                <div class="card card-body p-2 rounded mb-4">
                    <div class="d-flex justify-content-between">
                        <div class="icon">
                            <h2 class="bg-success p-3 mt-1 rounded-circle text-white"><i class="fa fa-gem"></i></h2>
                        </div>
                        <div>
                            <p class="mb-0 mt-2 text-muted">All Products</p>
                            <h4 class="mb-0 mt-2 text-right"><?php echo e($allproducts); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                <div class="card card-body p-2 rounded mb-4">
                    <div class="d-flex justify-content-between">
                        <div class="icon">
                            <h2 class="bg-success p-3 mt-1 rounded-circle text-white"><i class="fa fa-shopping-cart"></i></h2>
                        </div>
                        <div>
                            <p class="mb-0 mt-2 text-muted">Processing Order</p>
                            <h4 class="mb-0 mt-2 text-right"><?php echo e($processingOrder); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\ecommerce\resources\views/admins/dashboard.blade.php ENDPATH**/ ?>