<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activepage' => 'order']); ?>

    <?php $__env->startSection('title', "Order Details"); ?>

    <?php $__env->startSection('description', "Welcome to Yip Online Ecommerce"); ?>
    <?php $__env->startSection('ogTitle', 'Welcome to Yip Online Ecommerce'); ?>
    <?php $__env->startSection('ogImage', asset('assets/images/yip-online.png')); ?>
    <?php $__env->startSection('ogUrl', Request::url()); ?>


    <div class='productwrapper'>
        <section class='container'>
            <div class="row d-flexx justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-5 mb-4">
                    <div class="eachSortSect">
                        <div class="d-flex justify-content-between bg-light pt-2 pl-3 pr-3 pb-1 mb-4">
                            <div class="widget-title">
                                <h6 class="title m-b30">Order Details</span></h6>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <p>Order Number:</p>
                            <p><?php echo e(strtoupper($order->order_number)); ?> </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <p>Order Status:</p>
                            <p>
                                <?php if($order->status == 'pending'): ?>
                                <span class="bg-gray text-info" style="font-size: 13px">Pending</span>
                                <?php elseif($order->status == 'delivered'): ?>
                                <span class="bg-gray text-success" style="font-size: 13px">Delivered</span>
                                <?php elseif($order->status == 'cancelled'): ?>
                                <span class="bg-gray text-danger" style="font-size: 13px"><?php echo e($order->status); ?></span>
                                <?php elseif($order->status == 'processing'): ?>
                                <span class="bg-gray text-warning" style="font-size: 13px"><?php echo e($order->status); ?></span>
                                <?php elseif($order->status == 'shipped'): ?>
                                <span class="bg-gray text-info" style="font-size: 13px"><?php echo e($order->status); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <p>Payment Method:</p>
                            <p>
                                <?php if($order->payment_method == 'pay_now'): ?>
                                Instant Payment
                                <?php else: ?>
                                Pay on delivery
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <p>Created On:</p>
                            <p><?php echo e(date('d M, Y', strtotime($order->created_at))); ?> </p>
                        </div>


                        <div class="d-flex justify-content-between bg-light pt-2 pl-3 pr-3 pb-1 mb-4">
                            <div class="widget-title">
                                <h6 class="title m-b30">Shipping Adress</span></h6>
                            </div>
                        </div>
                        <div class="">
                            <p class="mb-0">Address:</p>
                            <p><?php echo e($order->address); ?> </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <p>State:</p>
                            <p><?php echo e($order->state); ?> </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <p>Country:</p>
                            <p><?php echo e($order->country); ?> </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <p>Phone:</p>
                            <p><?php echo e($order->phone); ?> </p>
                        </div>

                    </div>
                </div>
                <div class="col-xl-8 col-lg-8 col-md-7 mb-4">
                    
                    <div class="eachSortSect">
                        <div class="d-flex justify-content-between bg-light pt-2 pl-3 pr-3 pb-1 mb-4">
                            <div class="widget-title">
                                <h6 class="title m-b30">Products</span></h6>
                            </div>
                        </div>

                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row orderDetails mb-4">
                            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2 col-3 forcartImgDiv">
                                <img src="<?php echo e($pro->image); ?>" class="cartimg" alt="/">
                            </div>
                            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-9">
                                <div class="dz-head">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="title mb-0"><?php echo e($pro->name); ?></h6>
                                    </div>
                                </div>
                                <div class="dz-body mt-3">
                                    <p class="mb-1 text-muted">
                                        <span>category:</span>
                                        <?php echo e(ucwords(str_replace('-', ' ', $pro->category))); ?>

                                    </p>
                                    <p class="mb-1 text-muted">
                                        <span>Price:</span> <?php echo e(number_format($pro->price)); ?>,
                                        <span>Qty:</span> <?php echo e($pro->quantity); ?>,
                                    </p>
                                    <p class="mb-1 text-muted">
                                        <span>Total Price:</span>
                                        <?php echo e($curr); ?><?php echo e(number_format($pro->price * $pro->quantity)); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>

                        <div class="d-flex justify-content-end mb-2">
                            <div class="text-muted mr-4">Sub Total</div>
                            <div class="price"><?php echo e($curr); ?><?php echo e(number_format($order->total_amount)); ?></div>
                        </div>
                        <div class="d-flex justify-content-end mb-2">
                            <div class="text-muted mr-4">Shipping Fee</div>
                            <div class="price"><?php echo e($curr); ?><?php echo e(number_format($order->shipping_fee)); ?></div>
                        </div>
                        <div class="d-flex justify-content-end mb-2">
                            <div class="text-muted mr-4">Coupon</div>
                            <div class="price">Null</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-end mb-4">
                            <div class="text-muted mr-4">Total</div>
                            <div class="price"><strong><?php echo e($curr); ?><?php echo e(number_format($order->total_amount + $order->shipping_fee)); ?></strong></div>
                        </div>
                    </div>
                </div>

            </div>
        </section>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php /**PATH C:\Laravel\ecommerce\resources\views/users/order-details.blade.php ENDPATH**/ ?>